import mysql from "mysql";

export const db = mysql.createConnection({
  host: "localhost",
  user: "Beagle",
  password: "",
  database: "social",
});



